import React from 'react'

type Props = {}

const Skeleton = (props: Props) => {
 return (
  <div>ProductsSkeleton</div>
 )
}

export default Skeleton